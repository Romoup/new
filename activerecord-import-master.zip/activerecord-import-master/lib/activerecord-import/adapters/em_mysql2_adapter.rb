require "activerecord-import/adapters/mysql_adapter"

module ActiveRecord::Import::EMMysql2Adapter
  include ActiveRecord::Import::MysqlAdapter
end
