module ActiveRecord
  module Import
    VERSION = "1.0.1".freeze
  end
end
