require File.expand_path(File.dirname(__FILE__) + '/../test_helper')
require File.expand_path(File.dirname(__FILE__) + '/../support/sqlite3/import_examples')

should_support_sqlite3_import_functionality
