ENV["ARE_DB"] = "jdbcmysql"
