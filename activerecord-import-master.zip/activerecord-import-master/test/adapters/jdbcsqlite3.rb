ENV["ARE_DB"] = "jdbcsqlite3"
