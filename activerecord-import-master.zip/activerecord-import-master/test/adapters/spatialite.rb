ENV["ARE_DB"] = "spatialite"
