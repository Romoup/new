require File.expand_path(File.dirname(__FILE__) + '/postgresql_schema')
