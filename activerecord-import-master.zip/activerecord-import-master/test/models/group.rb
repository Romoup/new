class Group < ActiveRecord::Base
  self.table_name = 'group'
end
