class Car < ActiveRecord::Base
  self.primary_key = :Name
end
