class Promotion < ActiveRecord::Base
  self.primary_key = :promotion_id
end
