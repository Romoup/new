class Question < ActiveRecord::Base
  has_one :rule
end
