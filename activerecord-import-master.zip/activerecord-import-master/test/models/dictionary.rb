require_relative 'book'

class Dictionary < Book
end
