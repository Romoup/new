class Alarm < ActiveRecord::Base
end
