class TestMemory < ActiveRecord::Base
  self.table_name = 'test_memory'
end
