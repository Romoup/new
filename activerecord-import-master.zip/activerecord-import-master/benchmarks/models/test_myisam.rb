class TestMyISAM < ActiveRecord::Base
  self.table_name = 'test_myisam'
end
