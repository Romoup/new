class TestInnoDb < ActiveRecord::Base
  self.table_name = 'test_innodb'
end
