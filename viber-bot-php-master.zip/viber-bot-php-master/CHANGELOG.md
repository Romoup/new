# CHANGELOG

## 0.0.12
+ improve code style
+ add onPicture method

## 0.0.5

+ signature inside QS

## 0.0.4

+ fix #13, fix #12, fix unit test

## 0.0.3

+ drop HHVM support
+ fix typos
+ sync with set_webhook api call
