<?php

namespace Viber\Api\Event;

use Viber\Api\Event;

/**
 * Triggers when setting a webhook
 *
 * @author An Hoang <hoangthienan@gmail.com>
 */
class Webhook extends Event
{
}
